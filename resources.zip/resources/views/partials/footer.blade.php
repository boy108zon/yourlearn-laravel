<footer class="footer border-top pt-4">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <a href="https://yourlearn.in" class="text-muted"><strong>YourLearn</strong></a>
                </p>
            </div>

            <div class="col-6 text-end">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item me-3"><a href="https://yourlearn.in" class="text-muted">Contact</a></li>
                    <li class="list-inline-item me-3"><a href="https://yourlearn.in" class="text-muted">About Us</a></li>
                    <li class="list-inline-item me-3"><a href="https://yourlearn.in" class="text-muted">Terms</a></li>
                    <li class="list-inline-item"><a href="https://yourlearn.in" class="text-muted">Booking</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
