<div class="product-reviews text-center">
    <h5 class="mb-1">{{ number_format($averageRating, 1) }} ⭐️</h5>
    <small class="text-muted">{{ number_format($ratingCount / 1000, 1) }}k Ratings</small>
</div>
